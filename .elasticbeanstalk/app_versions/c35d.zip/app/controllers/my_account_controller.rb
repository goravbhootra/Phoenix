class MyAccountController < ApplicationController
  def show
  end
end
