class DashboardsController < ApplicationController
  def home

  end
end
