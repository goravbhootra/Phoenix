class Account::CurrentLiability < Account
  self.normal_credit_balance = true
end
