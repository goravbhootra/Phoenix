class Account::SundryCreditor < Account::CurrentLiability
end
