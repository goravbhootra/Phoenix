class Account::SundryDebtor < Account::CurrentAsset
end
