class Account::CurrentAsset < Account
  self.normal_credit_balance = false
end
