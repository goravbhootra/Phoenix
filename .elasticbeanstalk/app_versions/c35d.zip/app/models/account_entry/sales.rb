class AccountEntry::Sales < AccountEntry::Credit
end
