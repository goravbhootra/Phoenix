class JournalVoucher < AccountTxn
end
