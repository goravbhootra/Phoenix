# ActiveSupport::CoreExtensions::Date::Conversions::DATE_FORMATS[:default] = '%d/%m/%Y'
Date::DATE_FORMATS[:default] = "%d/%m/%Y"
