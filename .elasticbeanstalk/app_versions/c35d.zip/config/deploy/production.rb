# Simple Role Syntax
# ==================
# Supports bulk-adding hosts to roles, the primary server in each group
# is considered to be the first unless any hosts have the primary
# property set.  Don't declare `role :all`, it's a meta role.

set :stage, :production
set :shared_path, '/var/phoenix/shared'

set :deploy_to, "/var/phoenix"
set :ssh_options, { forward_agent: true }
set :branch, ENV['BRANCH'] || 'master'
# set :normalize_asset_timestamps, false
set :nginx_server_name, 'staging.manapakkam.com'

# set :unicorn_service, "unicorn_#{fetch(:application)}"
# set :unicorn_workers, 2
set :puma_threads, [4, 8]
set :puma_workers, 2
# set :puma_bind,       "unix://#{shared_path}/tmp/sockets/#{fetch(:application)}-puma.sock"
# set :puma_state,      "#{shared_path}/tmp/pids/puma.state"
# set :puma_pid,        "#{shared_path}/tmp/pids/puma.pid"
set :puma_bind,       "unix:///var/phoenix/shared/tmp/sockets/phoenix-puma.sock"
set :puma_state,      "/var/phoenix/shared/tmp/pids/puma.state"
set :puma_pid,        "/var/phoenix/shared/tmp/pids/puma.pid"
set :puma_access_log, "#{release_path}/log/puma.error.log"
set :puma_error_log,  "#{release_path}/log/puma.access.log"
# set :ssh_options,     { forward_agent: true, user: fetch(:user), keys: %w(~/.ssh/id_rsa.pub) }
set :puma_preload_app, true
set :puma_worker_timeout, 90
set :puma_init_active_record, true  # Change to true if using ActiveRecord

role :app, %w{phoenix@178.79.136.146:1222}
role :web, %w{phoenix@178.79.136.146:1222}
role :db,  %w{phoenix@178.79.136.146:1222}
role :worker, %w{phoenix@178.79.136.146:1222}

# Extended Server Syntax
# ======================
# This can be used to drop a more detailed server definition into the
# server list. The second argument is a, or duck-types, Hash and is
# used to set extended properties on the server.

# server 'example.com', user: 'deploy', roles: %w{web app}, my_property: :my_value

# Custom SSH Options
# ==================
# You may pass any option but keep in mind that net/ssh understands a
# limited set of options, consult[net/ssh documentation](http://net-ssh.github.io/net-ssh/classes/Net/SSH.html#method-c-start).
#
# Global options
# --------------
#  set :ssh_options, {
#    keys: %w(/home/rlisowski/.ssh/id_rsa),
#    forward_agent: false,
#    auth_methods: %w(password)
#  }
#
# And/or per server (overrides global)
# ------------------------------------
# server 'example.com',
#   user: 'user_name',
#   roles: %w{web app},
#   ssh_options: {
#     user: 'user_name', # overrides user setting above
#     keys: %w(/home/user_name/.ssh/id_rsa),
#     forward_agent: false,
#     auth_methods: %w(publickey password)
#     # password: 'please use keys'
#   }
